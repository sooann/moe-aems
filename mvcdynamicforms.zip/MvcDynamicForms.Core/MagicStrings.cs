﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MvcDynamicForms.Utilities
{
    internal static class MagicStrings
    {
        internal static string MvcDynamicSerializedForm 
        {
            get
            { 
                return "MvcDynamicSerializedForm"; 
            } 
        }
    }
}
